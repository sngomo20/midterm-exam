const MD = require('../models/dbmd');
const date =new Date();
exports.create = (req,res) => {
    


    if(!req.body.major){
        return res.status(400).send({'message': 'Allocate a major'})
    }
    
    const md = new MD({
    
    name :req.body.name || 'Untitled', 
    age :req.body.age, 
    major :req.body.major,
    createdDate : date,
    updatedDate : date
    })

    md.save()
    .then(data=> res.send(data))
    .catch(err => {
        res.status(500).send({'message':'Something went wrong!!',
           'error':err
        })
    });
}

exports.findAll = (req,res)=>{
    MD.find().then(
        md =>{
           res.send(md)
        }
    ).catch(err => {
        res.status(500).send({'message':'Something went wrong!!',
           'error':err
        })
    })
}

exports.findOne = (req,res)=>{
    console.log(req.params.id);

    MD.findById(req.params.id).then(
        md =>{

            if(!md){
                res.status(404).send({"message" : "ID not found"})
            }
           res.send(md)
        }
    ).catch(err => {
        res.status(500).send({'message':'Something went wrong!!',
           'error':err
        })
    })
}

exports.update = (req, res)=>{

    if(!req.body.major){
        return res.status(400).send({'message': 'Description cant be empty'})
    }

    MD.findByIdAndUpdate(req.params.id,{
        name :req.body.name || 'Untitled',
        age :req.body.age, 
    major :req.body.major,
    createdDate : req.body.createdDate,
    updatedDate : date
        
    }, {new : true} ).then(
        md =>{

            if(!md){
                res.status(404).send({"message" : "ID not found"})
            }
           res.send(md)
        }
    ).catch(err => {
        res.status(500).send({'message':'Something went wrong!!',
           'error':err
        })
    })
}

exports.delete = (req,res)=>{
    MD.findByIdAndRemove(req.params.id).then(
        md =>{

            if(!md){
                res.status(404).send({"message" : "ID not found"})
            }
           res.send({"message" : "I got deleted!!"})
        }
    ).catch(err => {
        res.status(500).send({'message':'Something went wrong!!',
           'error':err
        })
    })
}