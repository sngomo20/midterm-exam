module.exports= (app)=>{

    const md= require('../controller/dbcontroller');

    //create a student
    app.post('/md',md.create);

    //retrieve all student
    app.get('/md',md.findAll);

    //retrieve a student by ID
    app.get('/md/:id',md.findOne);

    // update a student
    app.put('/md/:id',md.update);

    //delete a student
    app.delete('/md/:id',md.delete);

}